 <!-- Home slider -->
 <?php include 'elements/slider.php' ?>
 <!-- Home slider end -->

 <!-- Top Collection -->
 <!-- Title-->
 <div class="title1 section-t-space title5">
     <h2 class="title-inner1">Sản phẩm nổi bật</h2>
     <hr role="tournament6">
 </div>
 <!-- Product slider -->
 <section class="section-b-space p-t-0 j-box ratio_asos">
     <?php include 'elements/product-slider.php' ?>
 </section>
 <!-- Product slider end -->
 <!-- Top Collection end-->

 <!-- service layout -->
 <div class="container">
     <?php include 'elements/service.php' ?>
 </div>
 <!-- service layout  end -->

 <!-- Tab product -->

 <div class="title1 section-t-space title5">
     <h2 class="title-inner1">Danh mục nổi bật</h2>
     <hr role="tournament6">
 </div>
 <section class="p-t-0 j-box ratio_asos">
     <?php include 'elements/category.php' ?>
 </section> <!-- Tab product end -->

 <!-- Quick-view modal popup start-->
 <?php include 'elements/modal.php' ?>
 <!-- Quick-view modal popup end-->

 <!-- footer -->