<?php
	echo '<h3>' . __FILE__ . '</h3>';
	echo'<pre>';
	print_r ($this->data);
	echo '</pre>';