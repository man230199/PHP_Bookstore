<?php
	
	// ====================== PATHS ===========================
	define ('EDIT_SUCCESS_NOTIFY'	, 'Cập nhật thành công');
	define ('ADD_SUCCESS_NOTIFY'	, 'Thêm thành công');						// Định nghĩa đường dẫn đến thư mục gốc
			
