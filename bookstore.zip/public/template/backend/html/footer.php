<footer class="main-footer">
    <strong>Copyright &copy; 2021
        <a href="https://zendvn.com/">ZendVN.com</a>.</strong>
    All rights reserved.
</footer>