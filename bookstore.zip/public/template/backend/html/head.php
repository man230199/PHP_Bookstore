
<title>Admin Panel</title>

<?php echo $this->_metaHTTP; ?>
<?php echo $this->_metaName; ?>
<?php echo $this->_title; ?>
<?php echo $this->_pluginCss; ?>
<?php echo $this->_cssFiles; ?>



