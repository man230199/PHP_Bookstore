<?php echo $this->_pluginJs; ?>
<?php echo $this->_jsFiles; ?>
<script>
    CKEDITOR.replace('form[short_description]');
    CKEDITOR.replace('form[description]');
</script>